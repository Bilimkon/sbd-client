CREATE VIEW product_v AS
  SELECT
    p.id AS     id,
    CASE p.unit
    WHEN '1'
      THEN 'Dona'
    WHEN '2'
      THEN 'Kg'
    END  AS     unit,
    p.barcode   barcode,
    p.name      name,
    p.type      type,
    p.cost_o    cost_o,
    p.cost      cost,
    p.quantity  quantity,
    p.quantity*p.cost_o total_cost_o,
    p.quantity*p.cost total_cost,
    p.date_c    date_c,
    p.date_o    date_o,
    s.firstName suplier,
    p.date_cr
  FROM product p
    JOIN suplier s
  WHERE p.suplier_id = s.id;


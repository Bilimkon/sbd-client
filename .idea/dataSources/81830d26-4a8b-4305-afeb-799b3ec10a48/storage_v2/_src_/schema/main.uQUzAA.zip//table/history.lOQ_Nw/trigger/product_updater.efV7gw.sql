CREATE TRIGGER product_updater
  after INSERT
on history
  for each row
BEGIN
update product set quantity = quantity - new.product_quantity where barcode = new.product_barcode;
END;

